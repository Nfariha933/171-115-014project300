
<?php $__env->startSection('content'); ?>

<section id="Categories">
 <div class="Categories_m clearfix">
  <div class="container">
    <div class="row">
       <div class="col-sm-12 space_all">
        <div class="Categories_1 text-center clearfix">
         <h1>POPULAR COURSES</h1>
        </div>

                  <div id="Categories_2i" class="tab-pane fade in active clearfix">
                   <div class="clearfix c_tagm">
                       <div class="col-sm-4">
                        <div class="cat_tag clearfix" style="border-style: groove;
                        text-align:justify;">
                            <div class="cat_tagi clearfix">
                              <div class="grid clearfix">
                             <h2 style="border-bottom-style:double;">SHORT DRIVING</h2>
                             <h4><i class="fa fa-money" style="color:#bf3f22"></i> ৳ 3,000 BDT</i></h4>
                                <h4><i class="fa fa-check" style="color:#03fc77"></i>Course : 12 Days</i></h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>Dueration : 30 Minute/Class</h4>
                                     <h4><i class="fa fa-check" style="color:#03fc77"></i>Practical : 7 Days</h4>
                                  <h4><i class="fa fa-check" style="color:#03fc77"></i>Theory : 5 Days</h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>1st Installment : 3,000 BDT</h4>
                                    <h4><i class="fa fa-close" style="color:#fc0303" ></i>2nd Installment : No</h4>
                                    <button type="Apply Now"  class="button"><a href="<?php echo e(URL::to('/admission')); ?>">Apply Now</a></button>
                             </div>
                              <ul>
                               <li><a href="#"><i class="fa fa-download"></i></a></li>
                               <li><a href="#"><i class="fa fa-comments"></i></a></li>
                              </ul>
                              <ul class="star-list">
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                    </ul>
                            </div>
                            
                         </div>
                       </div>
                       <div class="col-sm-4">
                        <div class="cat_tag clearfix" style="border-style: groove;
                        text-align:justify;">
                            <div class="cat_tagi clearfix">
                              <div class="grid clearfix">
                             <h2 style="border-bottom-style:double;">SECOND DRIVING</h2>
                              <h4><i class="fa fa-money" style="color:#bf3f22"></i> ৳ 4,500 BDT</i></h4>
                                <h4><i class="fa fa-check" style="color:#03fc77"></i>Course : 18 Days</i></h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>Dueration : 30 Minute/Class</h4>
                                     <h4><i class="fa fa-check" style="color:#03fc77"></i>Practical : 10 Days</h4>
                                  <h4><i class="fa fa-check" style="color:#03fc77"></i>Theory : 8 Days</h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>1st Installment : 3,500 BDT</h4>
                                    <h4><i class="fa fa-check" style="color:#03fc77" ></i> 2nd Installment : 1,000 BDT After 7 Classes</h4>
                                      
                                    <button type="Apply Now"  class="button"><a href="<?php echo e(URL::to('/admission')); ?>">Apply Now</a></button>
                             </div>
                              <ul>
                               <li><a href="#"><i class="fa fa-download"></i></a></li>
                               <li><a href="#"><i class="fa fa-comments"></i></a></li>
                              </ul>
                              <ul class="star-list">
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                    </ul>
                            </div>
                        
                         </div>
                            
                       </div>
                       <div class="col-sm-4">
                        <div class="cat_tag clearfix" style="border-style: groove;
                        text-align:justify;">
                            <div class="cat_tagi clearfix">
                              <div class="grid clearfix">
                             <h2 style="border-bottom-style:double;">BASIC DRIVING</h2>
                              <h4><i class="fa fa-money" style="color:#bf3f22"></i> ৳ 7,000 BDT</i></h4>
                            
                                <h4><i class="fa fa-check" style="color:#03fc77"></i>Course : 30 Days</i></h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>Dueration : 30 Minute/Class</h4>
                                     <h4><i class="fa fa-check" style="color:#03fc77"></i>Practical : 20 Days</h4>
                                  <h4><i class="fa fa-check" style="color:#03fc77"></i>Theory : 10 Days</h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i> 1st Installment : 4,000 BDT</h4>
                                    <h4><i class="fa fa-check" style="color:#03fc77" ></i> 2nd Installment : 3,000 BDT After 7 Classes</h4>
                                      
                                    <button type="Apply Now"  class="button"><a href="<?php echo e(URL::to('/admission')); ?>">Apply Now</a></button>
                             </div>
                              <ul>
                               <li><a href="#"><i class="fa fa-download"></i></a></li>
                               <li><a href="#"><i class="fa fa-comments"></i></a></li>
                              </ul>
                              <ul class="star-list">
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                    </ul>
                            </div>
                        
                       </div>
                   </div>
                </div> 
                  </div>
                </div>
  </div>
 </div>
 </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\drivingzone\resources\views/pages/course.blade.php ENDPATH**/ ?>