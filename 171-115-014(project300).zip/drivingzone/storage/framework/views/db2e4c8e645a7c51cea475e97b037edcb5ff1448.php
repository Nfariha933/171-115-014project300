<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Driving Zone</title>
	<link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontend/css/global.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('frontend/css/detail.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" />
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<script src="<?php echo e(asset('frontend/js/jquery-2.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
  </head>
  
<body>
<section id="top">
 <div class="container">
  <div class="row">
   <div class="col-sm-12">
    <div class="col-sm-6 space_all">
     <div class="top_1 clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="top_1l clearfix">
		 <ul>
		 <li><a href="#"><i class="fa fa-envelope"></i> drivingschool@gmail.com</a></li>
		 </ul>
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="top_1l clearfix">
		 <ul>
		 <li><a href="#"><i class="fa fa-phone"></i> 01740069653</a></li>
		 </ul>
		</div>
	   </div>
	 </div>	
	</div>
	<div class="col-sm-6 space_all">
     <div class="top_1 text-right clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="top_1l clearfix">
		
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="top_1r clearfix">
		 <ul class="social-network social-circle">
                        
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
		</div>
	   </div>
	 </div>	
	</div>
   </div>
  </div>
 </div>
</section>
<section id="header" class="cd-secondary-nav clearfix">
	<nav class="navbar">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>"><span class="brand_1">D</span>Driving Zone<span class="brand_2">DRIVING SCHOOL</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="tag_m active_tab" href="<?php echo e(URL::to('/')); ?>">Home</a>
                </li>
                    
                <li>
                    <a class="tag_m" href="<?php echo e(URL::to('/course')); ?>">Courses</a>
                </li>
                
                <li>
                    <a class="tag_m" href="<?php echo e(URL::to('/blog')); ?>">Blog</a>
                </li>
                
                <li>
                    <a class="tag_m" href="<?php echo e(URL::to('/detail')); ?>">Details</a>
                </li>
                <li>
                    <a class="tag_m" href="<?php echo e(URL::to('/about')); ?>">About Us</a>
                </li>
                
                <li>
                    <a class="tag_m" href="<?php echo e(URL::to('/contact')); ?>">Contact</a>
                </li>

			        <li>
                        <a class="tag_m tag_m2" href="<?php echo e(URL::to('/admission')); ?>">Get Admission</a>
                    </li>
					
					<li class="dropdown">
					  <a class="tag_m" href="#" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-user"></i>Account<span class="caret"></span></a>
					  <ul class="dropdown-menu drop_1" role="menu">
						<li><a href="<?php echo e(URL::to('/admin')); ?>">Admin Login</a></li>
						<li><a href="<?php echo e(URL::to('/std_login')); ?>">Students Login</a></li>
					  </ul> 
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</section>
					
					

<section id="center" class="center_detail clearfix">
 <div class="center_course_m clearfix">
  <div class="container">
   <div class="row">
    <div class="col-sm-12">
	 <div class="center_course_1 text-center clearfix">
	  <h1 class="mgt">BLOG DETAILS</h1>
	 
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="blog_detail">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="blog_detail_1 clearfix">
	 <div class="col-sm-9">
	  <div class="blog_detail_1l clearfix">
	     <div class="grid clearfix">
				  <figure class="effect-jazz">
					<a href="#"><img src="<?php echo e(asset('frontend/img/52.jpg')); ?>" class="iw mgt" alt="img25"></a>
				  </figure>
		 </div>
		 <div class="article_1r clearfix">
		   <ul>
			<li><a class="date" href="#"><i class="fa fa-calendar"></i> November 23, 2019</a></li>
			<li><a class="text" href="#">Personal life</a></li>
		   </ul>
		   <h2><a href="#">Helping People Grow Their Careers. Every Day!</a></h2>
		   <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor. Proin egestas euismod felis a ullamcorper. Nullam lacus nisi, blandit eget lacus ac, lobortis finibus augueSed ut perspiciatis ude omni iste natus error sit voluptatem doloremque laudantium, totam rem aperiam, eaque ipsa qua tore veritatis.</p>
	  </div>
	  </div>
	  <div class="blog_detail_1l1 clearfix">
	   <div class="col-sm-9 space_left blog_detail_1l1i">
	    <h4 class="mgt">NEW COURSE ARE LAUNCHED</h4>
		<h3>Military Engineering Course at General Dhagabadan</h3>
	   </div>
	   <div class="col-sm-3 space_right">
	     <h4 class="mgt"><a class="button_1 mgt" href="#">Start Learning</a></h4>
	   </div>
	  </div>
	  <div class="blog_detail_1l2 clearfix">
	   <div class="col-sm-7 space_left">
	    <p class="mgt">et quasi ut architecto beatae vitae dicta sunt ex mo enim ipsam voluptatem quia valum voluptas.Sed ut perspiciatis ude omni iste natus error sit voluptatem doloremque laudantium, totam rem aperiam, eaque ipsa qua tore veritatis et quasi ut architecto beatae vitae dicta sunt ex mo enim ipsam voluptatem quia valum voluptas.</p>
		<p>Sed ut perspiciatis ude omni iste natus error sit voluptatem doloremque laudantium, totam rem a enim ipsam voluptatem quia valum voluptas.</p>
	   </div>
	   <div class="col-sm-5 space_right">
	     <div class="blog_detail_1l2i1 clearfix">
			<h3 class="mgt">Related Articles</h3>
			<p><a href="#"><i class="fa fa-caret-right"></i> Making Cents Investments....</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Wall Street For Surfing Victirea</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Your Lead Own Business po...</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Street For Surfing Victirea</a></p>
		 </div>
	   </div>
	  </div>
	  <div class="blog_detail_1l3 clearfix">
		  <p class="mgt">Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor. Proin egestas euismod felis a ullamcorper. Nullam lacus nisi, blandit eget lacus ac, lobortis finibus augueSed ut perspiciatis ude omni iste natus error sit voluptatem doloremque laudantium, totam rem aperiam, eaque ipsa qua tore veritatis.
		  </p>
		  <div class="grid clearfix">
				  <figure class="effect-jazz">
					<a href="#"><img src="<?php echo e(asset('frontend/img/53.jpg')); ?>" class="iw" alt="img25"></a>
				  </figure>
		 </div>
		 <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor. Proin egestas euismod felis a ullamcorper. Nullam lacus nisi, blandit eget lacus ac, lobortis finibus augueSed ut perspiciatis ude omni iste natus error sit voluptatem doloremque laudantium, totam rem aperiam, eaque ipsa qua tore veritatis.</p>
	  </div>
	  <div class="blog_detail_1l4 clearfix">
	   <div class="col-sm-12 space_all">
	     <div class="col-sm-6 space_left">
	    <div class="grid clearfix">
				  <figure class="effect-jazz">
					<a href="#"><img src="<?php echo e(asset('frontend/img/54.jpg')); ?>" class="iw mgt" height="270" alt="img25"></a>
				  </figure>
		 </div>
	   </div>
	     <div class="col-sm-6 space_right">
	    <p><i class="fa fa-bullhorn"></i> Pellentesque ultrices orci id justo vehic</p>
		<p><i class="fa fa-bullhorn"></i> ula, non aliquam erat lacinia. Mauris rh</p>
		<p><i class="fa fa-bullhorn"></i> oncus venenatis tempor. Proin egestas</p>
		<p><i class="fa fa-bullhorn"></i> euismod felis a ullamcorper. Nullam lac</p>
		<p><i class="fa fa-bullhorn"></i> us nisi, blandit eget lacus ac, lobortis fin</p>
		<p><i class="fa fa-bullhorn"></i> ibus augueSed ut perspiciatis ude omni</p>
	   </div>
	   </div>
	   <div class="col-sm-12 space_all">
	    <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis totam rem aperiam, eaque ipsa qua tore veritatis.</p>
	   </div>
	  </div>
	  <div class="blog_detail_1l5 clearfix">
	   <ul>
	    <li><i class="fa fa-tag"></i> Tags:</li>
		<li><a href="#">Fashion</a></li>
		<li><a href="#">Books</a></li>
		<li><a href="#">News</a></li>
	   </ul>
	  </div>
	  <div class="blog_detail_1l6 clearfix">
	   <div class="col-sm-4 space_left">
	    <div class="blog_detail_1l6l clearfix">
		 <a href="#"><img src="<?php echo e(asset('frontend/img/55.jpg')); ?>" class="iw thumbnail mgt" alt="abc" height="180"></a>
		</div>
	   </div>
	   <div class="col-sm-8 space_right">
	    <div class="blog_detail_1l6r clearfix">
		 <div class="col-sm-12">
		 <div class="col-sm-6 space_left"><h3 class="mgt">About Author</h3></div>
		 <div class="col-sm-6 space_right"><ul class="social-network social-circle pull-right">
			<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
			<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
			<li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
		 </ul></div>
		 </div>
		 <div class="col-sm-12"><p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia Mam rem aperiam, eaque ipsa qua tore veritatis.</p></div>
		</div>
	   </div>
	  </div>
	  <div class="blog_detail_1l7 clearfix">
	   <h2>02 COMMENTS</h2>
	  </div>
	  <div class="blog_detail_1l6 clearfix">
	   <div class="col-sm-3 space_left">
	    <div class="blog_detail_1l6l clearfix">
		 <a href="#"><img src="<?php echo e(asset('frontend/img/56.jpg')); ?>" alt="abc" class="iw thumbnail mgt" height="180"></a>
		</div>
	   </div>
	   <div class="col-sm-9 space_right">
	    <div class="blog_detail_1l6r clearfix">
		 <div class="col-sm-12">
		 <div class="col-sm-6 space_left"><h3 class="mgt">Per Inceptos <span>May 28, 2019</span></h3></div>
		 <div class="col-sm-6 space_right text-right"><h5 class="mgt"><a href="#">Reply</a></h5></div>
		 </div>
		 <div class="col-sm-12"><p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia Mam rem aperiam, eaque ipsa qua tore veritatis.</p></div>
		</div>
	   </div>
	  </div>
	  <div class="blog_detail_1l6 clearfix">
	   <div class="col-sm-3 space_left">
	    <div class="blog_detail_1l6l clearfix">
		 <a href="#"><img src="<?php echo e(asset('frontend/img/57.jpg')); ?>" class="iw thumbnail mgt" alt="abc" height="180"></a>
		</div>
	   </div>
	   <div class="col-sm-9 space_right">
	    <div class="blog_detail_1l6r clearfix">
		 <div class="col-sm-12">
		 <div class="col-sm-6 space_left"><h3 class="mgt">Eget Nulla <span>May 28, 2019</span></h3></div>
		 <div class="col-sm-6 space_right text-right"><h5 class="mgt"><a href="#">Reply</a></h5></div>
		 </div>
		 <div class="col-sm-12"><p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia Mam rem aperiam, eaque ipsa qua tore veritatis.</p></div>
		</div>
	   </div>
	  </div>
	  <div class="blog_detail_1l8 clearfix">
	   <div class="blog_detail_1l8i clearfix"> 
	     <h2>LEAVE A COMMENT</h2>
	    <div class="col-sm-6 space_left">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-user"></i></label>
            <input class="form-control" placeholder="Full Name" type="text">
		  </div>
		</div>
		<div class="col-sm-6 space_right">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-envelope"></i></label>
            <input class="form-control" placeholder="Email Address" type="text">
		  </div>
		</div>
	   </div>
	   <div class="blog_detail_1l8i clearfix"> 
		<div class="col-sm-12 space_all">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-pencil"></i></label>
            <input class="form-control" placeholder="Subject" type="text">
		  </div>
		</div>
		<div class="col-sm-12 space_all">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-pencil"></i></label>
            <textarea class="form-control form_1" placeholder="Review"></textarea>
		  </div>
		</div>
		<div class="col-sm-12 space_all">
		   <h4><a class="button_1" href="#">SEND MESSAGE</a></h4>
		 </div>
		</div>
	   </div>
	  </div>
	 <div class="col-sm-3">
	   <div class="blog_detail_1r clearfix">
	    <div class="footer_1i2 clearfix">
	    <h3 class="mgt">Recent News</h3>
		<p><a href="#">New Your Focus to Prevent Overanalysis</a></p>
		<h5><a href="#"><i class="fa fa-clock-o"></i> May 18,2019</a></h5>
		<p><a href="#">Three Social Media Hacks for the Busy Entrepreneur</a></p>
		<h5><a href="#"><i class="fa fa-clock-o"></i> May 18,2019</a></h5>
	  </div>
	    <div class="blog_detail_1l2i1 clearfix">
			<h3 class="mgt">Categories</h3>
			<p><a href="#"><i class="fa fa-caret-right"></i> Furnitures</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Electronics</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Gaming Consoles</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Education Courses</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Books & Magazines</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> Fashion</a></p>
		 </div>
		<div class="blog_detail_1r1 clearfix">
		 <div class="blog_detail_1r1m clearfix">
		   <h3 class="mgt">Upcoming Events</h3>
		   <div class="clearfix">
		      <div class="col-sm-4 space_left">
			  <div class="blog_detail_1r1l">
			   <h4 class="mgt"><span>16</span> <br>Jun</h4>
			  </div>
		      </div>
		      <div class="col-sm-8 space_all">
		  <div class="blog_detail_1r1r">
		   <p class="mgt"><a href="#">Helping People<br> Grow Their<br> Careers.</a></p>
		  </div>
		 </div>
		   </div>
		  <h6><i class="fa fa-map-marker"></i> 141 Down Street, London </h6>
		  <hr>
		 </div>
		 <div class="blog_detail_1r1m clearfix">
		   <div class="clearfix">
		      <div class="col-sm-4 space_left">
			  <div class="blog_detail_1r1l">
			   <h4 class="mgt"><span>16</span> <br>Jun</h4>
			  </div>
		     </div>
		      <div class="col-sm-8 space_all">
		  <div class="blog_detail_1r1r">
		   <p class="mgt"><a href="#">Helping People<br> Grow Their<br> Careers.</a></p>
		  </div>
		 </div>
		   </div>
		  <h6><i class="fa fa-map-marker"></i> 141 Down Street, London </h6>
		  <hr>
		 </div>
		 <div class="blog_detail_1r1m clearfix">
		   <div class="clearfix">
		      <div class="col-sm-4 space_left">
			  <div class="blog_detail_1r1l">
			   <h4 class="mgt"><span>16</span> <br>Jun</h4>
			  </div>
		      </div>
		      <div class="col-sm-8 space_all">
		  <div class="blog_detail_1r1r">
		   <p class="mgt"><a href="#">Helping People<br> Grow Their<br> Careers.</a></p>
		  </div>
		 </div>
		   </div>
		  <h6><i class="fa fa-map-marker"></i> 141 Down Street, London </h6>
		 </div>
		</div>
		<div class="blog_detail_1l2i1 clearfix">
			<h3 class="mgt">Archives</h3>
			<p><a href="#"><i class="fa fa-caret-right"></i> February, 2018</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> April, 2018</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> May, 2018</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> June, 2018</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> July, 2018</a></p>
			<p><a href="#"><i class="fa fa-caret-right"></i> December, 2018</a></p>
		 </div>
		<div class="blog_detail_1r2 text-center clearfix">
		 <h3>NEWSLETTER</h3>
		 <p>Subscribe Our Newsletter and Get Updates.</p>
		 <input class="form-control" placeholder="Subscribe Email" type="text">
		 <h4 class="mgt"><a class="button_1" href="#">Subscribe Now</a></h4>
		</div>
	   </div>
	 </div>
	 </div>
	 
	</div>
   </div>
  </div>
</section>



<section id="footer">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	  	      <a class="navbar-brand" href="index.html"><span class="brand_1">D</span>riving Zone<span class="brand_2">DRIVING SCHOOL</span></a>
	   <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor.</p>
	   <ul>
	    <li><i class="fa fa-map-marker"></i> 21-23C Uvw Class Tu, Ad Nostra FA,</li>
		<li><i class="fa fa-envelope"></i> info@gmail.com</li>
		<li><i class="fa fa-phone"></i> +00 123 456 789</li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	   <div class="footer_1i1 clearfix">
	    <h3 class="mgt">Get in Touch</h3>
		<hr>
		<ul>
		 <li><a href="#"><i class="fa fa-facebook icon_1"></i> <span class="fb">Facebook</span></a></li>
		 <li><a href="#"><i class="fa fa-twitter icon_2"></i> <span class="tw">Twitter</span></a></li>
		 <li><a href="#"><i class="fa fa-google-plus icon_3"></i> <span class="gl">Google+</span></a></li>
		 <li><a href="#"><i class="fa fa-linkedin icon_4"></i> <span class="ld">Linkedin</span></a></li>
		</ul>
			<div class="input-group">
				<input type="text" class="form-control" placeholder="Subscribe Email">
				<span class="input-group-btn">
					<button class="btn btn-success" type="button">
						<i class="fa fa-envelope"></i></button>
				</span>
			</div>
	  </div>
	 </div>
	 <div class="col-sm-3">
	   <div class="footer_1i1 clearfix">
	    <h3 class="mgt">Gallery Images</h3>
		<hr>
		<div class="carousel slide" id="myCarousel">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="item" data-slide-number="0">
                                         <img src="<?php echo e(asset('frontend/img/44.jpg')); ?>" alt="abc" class="iw mgt">
										</div>

                                        <div class="item active" data-slide-number="1">
                                         <img src="<?php echo e(asset('frontend/img/45.jpg')); ?>" alt="abc" class="iw mgt">
										</div>

                                        <div class="item" data-slide-number="2">
                                         <img src="<?php echo e(asset('frontend/img/46.jpg')); ?>" alt="abc" class="iw mgt">
										</div>

                                    </div><!-- Carousel nav -->
                                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                        <span class="glyphicon glyphicon-chevron-left"></span>                                       
                                    </a>
                                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                                        <span class="glyphicon glyphicon-chevron-right"></span>                                       
                                    </a>                                
                                    </div>
	  </div>
	 </div>
	 <div class="col-sm-3">
	   <div class="footer_1i2 clearfix">
	    <h3 class="mgt">Recent News</h3>
		<hr>
		<p><a href="#">New Your Focus to Prevent Overanalysis</a></p>
		<h5 class="mgt"><a href="#"><i class="fa fa-clock-o"></i> May 28,2019</a></h5>
		<p><a href="#">Three Social Media Hacks for the Busy Entrepreneur</a></p>
		<h5 class="mgt"><a href="#"><i class="fa fa-clock-o"></i> May 28,2019</a></h5>
	  </div>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>



<script>
	$(document).ready(function() {              
    $('i.glyphicon-thumbs-up, i.glyphicon-thumbs-down').click(function(){    
        var $this = $(this),
        c = $this.data('count');    
        if (!c) c = 0;
        c++;
        $this.data('count',c);
        $('#'+this.id+'-bs3').html(c);
    });      
    $(document).delegate('*[data-toggle="lightbox"]', 'click', function(event) {
        event.preventDefault();
        $(this).ekkoLightbox();
    });                                        
}); 

	</script>

<script>
$(document).ready(function(){

/*****Fixed Menu******/
var secondaryNav = $('.cd-secondary-nav'),
   secondaryNavTopPosition = secondaryNav.offset().top;
	$(window).on('scroll', function(){
		if($(window).scrollTop() > secondaryNavTopPosition ) {
			secondaryNav.addClass('is-fixed');	
		} else {
			secondaryNav.removeClass('is-fixed');
		}
	});	
	
});
</script>

</body>
 
</html>
<?php /**PATH C:\xampp\htdocs\drivingzone\resources\views/pages/detail.blade.php ENDPATH**/ ?>