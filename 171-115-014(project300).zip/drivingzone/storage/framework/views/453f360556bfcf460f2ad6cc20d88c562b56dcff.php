
<?php $__env->startSection('content'); ?>

<section id="course">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="course_1">
     <div class="col-sm-4">
      <div class="course_1i text-center clearfix">
       <span><i class="fa fa-car"></i></span>
       <h3><a href="#">Sign up For Free</a></h3>
       <h4>Consulting Service</h4>
       <p>Remember though that life coaching is about delivering great results</p>
      </div>
     </div>
     <div class="col-sm-4">
      <div class="course_1i text-center clearfix">
       <span><i class="fa fa-taxi"></i></span>
       <h3><a href="#">License Renew</a></h3>
       <h4>Bachelor Degree, Honours</h4>
       <p>Remember though that life coaching is about delivering great results</p>
      </div>
     </div>
     <div class="col-sm-4">
      <div class="course_1i text-center clearfix">
       <span><i class="fa fa-motorcycle"></i></span>
       <h3><a href="#">Expert Trainers</a></h3>
       <h4>Course Socialism</h4>
       <p>Remember though that life coaching is about delivering great results</p>
      </div>
     </div>
    </div>
   </div>
  </div>
 </div>
</section>

<section id="skills">
 <div class="container">
  <div class="row">
    <div class="col-sm-12 space_all">
     <div class="skills_1 clearfix">
      <div class="col-sm-5">
       <div class="skills_1l clearfix">
         <div class="grid clearfix">
          <figure class="effect-jazz">
            <a href="#"><img src="<?php echo e(asset('frontend/img/4.jpg')); ?>" class="iw mgt" height="400" alt="img25"></a>
          </figure>
      </div>
       </div>
      </div>
      <div class="col-sm-7">
       <div class="skills_1r clearfix">
          <div class="col-sm-3 space_left">
              <ul class="nav nav-tabs">
                  <li class="active"><a data-toggle="tab" href="<?php echo e(URL::to('/about')); ?>">ABOUT US</a></li>
                  <li><a data-toggle="tab" href="<?php echo e(URL::to('/about')); ?>">OUR HISTORY</a></li>
                  <li><a data-toggle="tab" href="<?php echo e(URL::to('/about')); ?>">OUR SKILLS</a></li>
              </ul>
          </div>
          <div class="col-sm-9 space_left">
            <div class="tab-content clearfix">
              <div id="home" class="tab-pane fade in active clearfix">
                 <div class="click clearfix">
                   <h1 class="mgt">Inspiring The Next Generation Of Engineers Course</h1>
                   <p>Nullam suscipit id ante bibendum bibendum. Vivamus interdum gravida justo id venenatis. tempus velit sed, lobortis metus. Donec id tincidunt libero, eget dapibus quam. Aenean felis ex, blandit pretium pharetra eu.</p>
                  <h4><a class="button_1"  href="<?php echo e(URL::to('/about')); ?>">More Detail</a></h4> 
                 
                 </div>
              </div>
              <div id="menu1" class="tab-pane fade clearfix">
                 <div class="click clearfix">
                   <h1 class="mgt">Nullam Suscipit Id Ante Bibendum Vivamus Interdum</h1>
                   <p>Nullam suscipit id ante bibendum bibendum. Vivamus interdum gravida justo id venenatis. tempus velit sed, lobortis metus. Donec id tincidunt libero, eget dapibus quam. Aenean felis ex, blandit pretium pharetra eu.</p>
                   <h4><a class="button_1" href="#">More Detail</a></h4>
                 </div>
              </div>
              <div id="menu2" class="tab-pane fade clearfix">
                 <div class="click clearfix">
                   <h1 class="mgt">Gravida Justo Id Venenatis Tempus Velit Sed, Lobortis Metus</h1>
                   <p>Nullam suscipit id ante bibendum bibendum. Vivamus interdum gravida justo id venenatis. tempus velit sed, lobortis metus. Donec id tincidunt libero, eget dapibus quam. Aenean felis ex, blandit pretium pharetra eu.</p>
                   <h4><a class="button_1" href="<?php echo e(URL::to('/detail')); ?>">More Detail</a></h4>
                 </div>
              </div>
        </div>
          </div>
       </div>
      </div>
     </div>
    </div>
  </div>
 </div>
</section>

<section id="experts">
 <div class="experts_m clearfix">
  <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="experts_1">
     <div class="col-sm-6">
      <div class="experts_1l clearfix">
       <h1>Courses From The <span>World’s Leading Experts</span></h1>
       <p>Nullam suscipit id ante bibendum bibendum. Vivamus interdum gravida justo id venenatis. tempus velit sed, lobortis metus. Donec id tincidunt libero, eget dapibus quam. Aenean felis ex, blandit pretium pharetra eu.</p>
       <h4><a class="button" href="<?php echo e(URL::to('/admission')); ?>">Sign Up Now</a></h4>
      </div>
     </div>
     <div class="col-sm-6">
      <div class="experts_1r clearfix">
       <div class="col-sm-6 space_left">
         <div class="clearfix">
          <div class="col-sm-2 experts_1r1  space_all">
           <div class="clearfix">
            <span>Explore 289 Courses</span>
           </div>
          </div>
          <div class="col-sm-10 space_all">
           <div class="experts_1r2 text-center">
            <span><i class="fa fa-certificate"></i></span>
            <h3>Driving Certificate</h3>
           </div>
          </div>
         </div>
       </div>
       <div class="col-sm-6 space_left">
         <div class="clearfix">
          <div class="col-sm-2 experts_1r1 vr_1 space_all">
           <div class="clearfix">
            <span>Explore 289 Courses</span>
           </div>
          </div>
          <div class="col-sm-10 space_all">
           <div class="experts_1r2 text-center">
            <span><i class="fa fa-money"></i></span>
            <h3>Reasonable Price</h3>
           </div>
          </div>
         </div>
       </div>
      </div>
      <div class="experts_1r clearfix">
       <div class="col-sm-6 space_left">
         <div class="clearfix">
          <div class="col-sm-2 experts_1r1 vr_2 space_all">
           <div class="clearfix">
            <span>Explore 289 Courses</span>
           </div>
          </div>
          <div class="col-sm-10 space_all">
           <div class="experts_1r2 text-center">
            <span><i class="fa fa-users"></i></span>
            <h3>Expert Trainers</h3>
           </div>
          </div>
         </div>
       </div>
       <div class="col-sm-6 space_left">
         <div class="clearfix">
          <div class="col-sm-2 experts_1r1 vr_3 space_all">
           <div class="clearfix">
            <span>Explore 289 Courses</span>
           </div>
          </div>
          <div class="col-sm-10 space_all">
           <div class="experts_1r2 text-center">
            <span><i class="fa fa-check"></i></span>
            <h3>Job Placement</h3>
           </div>
          </div>
         </div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>
 </div>
 </div>
</section>

<section id="careers">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
     <div class="skills_1 clearfix">
      <div class="col-sm-6">
       <div class="skills_1l clearfix">
             <div class="grid clearfix">
                  <figure class="effect-jazz">
                    <a href="#"><img src="<?php echo e(asset('frontend/img/6.jpg')); ?>" class="iw mgt" height="400" alt="img25"></a>
                  </figure>
             </div>
       </div>
      </div>
      <div class="col-sm-6">
       <div class="skills_1r clearfix">
                   <h1 class="mgt">Helping People Grow Their Careers.</h1>
                   <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor. Proin egestas euismod felis a ullamcorper. Nullam lacus nisi, blandit eget lacus ac, lobortis finibus augue.</p>
                   <h4><a class="button_1" href="<?php echo e(URL::to('/about')); ?>">Start Learning</a></h4>
       </div>
      </div>
     </div>
     <div class="careers_1 clearfix">
      <div class="col-sm-3">
       <div class="careers_1i text-center clearfix">
        <h1>20</h1> 
        <h3>Years of Experience</h3>   
       </div>
      </div>
      <div class="col-sm-3">
       <div class="careers_1i text-center clearfix">
        <h1>15+</h1>    
        <h3>Years of Service</h3>   
       </div>
      </div>
      <div class="col-sm-3">
       <div class="careers_1i text-center clearfix">
        <h1>150+</h1>   
        <h3>Student</h3>   
       </div>
      </div>
     <div class="col-sm-3">
       <div class="careers_1i text-center clearfix">
        <h1>50+</h1>    
        <h3>Expert Trainers</h3>   
       </div>
      </div>
     </div>  
    </div>
  </div>
 </div>
</section>

<section id="Categories">
 <div class="Categories_m clearfix">
  <div class="container">
    <div class="row">
       <div class="col-sm-12 space_all">
        <div class="Categories_1 text-center clearfix">
         <h1>POPULAR COURSES</h1>
        </div>

                  <div id="Categories_2i" class="tab-pane fade in active clearfix">
                   <div class="clearfix c_tagm">
                       <div class="col-sm-4">
                        <div class="cat_tag clearfix" style="border-style: groove;
                        text-align:justify;">
                            <div class="cat_tagi clearfix">
                              <div class="grid clearfix">
                             <h2 style="border-bottom-style:double;">SHORT DRIVING</h2>
                             <h4><i class="fa fa-money" style="color:#bf3f22"></i> ৳ 3,000 BDT</i></h4>
                                <h4><i class="fa fa-check" style="color:#03fc77"></i>Course : 12 Days</i></h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>Dueration : 30 Minute/Class</h4>
                                     <h4><i class="fa fa-check" style="color:#03fc77"></i>Practical : 7 Days</h4>
                                  <h4><i class="fa fa-check" style="color:#03fc77"></i>Theory : 5 Days</h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>1st Installment : 3,000 BDT</h4>
                                    <h4><i class="fa fa-close" style="color:#fc0303" ></i>2nd Installment : No</h4>
                                   
                                   <button type="Apply Now"  class="button"><a href="<?php echo e(URL::to('/admission')); ?>">Apply Now</a></button>
                             </div>
                              <ul>
                               <li><a href="#"><i class="fa fa-download"></i></a></li>
                               <li><a href="#"><i class="fa fa-comments"></i></a></li>
                              </ul>
                              <ul class="star-list">
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                    </ul>
                            </div>
                            
                         </div>
                       </div>
                       <div class="col-sm-4">
                        <div class="cat_tag clearfix" style="border-style: groove;
                        text-align:justify;">
                            <div class="cat_tagi clearfix">
                              <div class="grid clearfix">
                             <h2 style="border-bottom-style:double;">SECOND DRIVING</h2>
                              <h4><i class="fa fa-money" style="color:#bf3f22"></i> ৳ 4,500 BDT</i></h4>
                                <h4><i class="fa fa-check" style="color:#03fc77"></i>Course : 18 Days</i></h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>Dueration : 30 Minute/Class</h4>
                                     <h4><i class="fa fa-check" style="color:#03fc77"></i>Practical : 10 Days</h4>
                                  <h4><i class="fa fa-check" style="color:#03fc77"></i>Theory : 8 Days</h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>1st Installment : 3,500 BDT</h4>
                                    <h4><i class="fa fa-check" style="color:#03fc77" ></i> 2nd Installment : 1,000 BDT After 7 Classes</h4>
                                      
                                    <button type="Apply Now"  class="button"><a href="<?php echo e(URL::to('/admission')); ?>">Apply Now</a></button>
                             </div>
                              <ul>
                               <li><a href="#"><i class="fa fa-download"></i></a></li>
                               <li><a href="#"><i class="fa fa-comments"></i></a></li>
                              </ul>
                              <ul class="star-list">
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                    </ul>
                            </div>
                        
                         </div>
                            
                       </div>
                       <div class="col-sm-4">
                        <div class="cat_tag clearfix" style="border-style: groove;
                        text-align:justify;">
                            <div class="cat_tagi clearfix">
                              <div class="grid clearfix">
                             <h2 style="border-bottom-style:double;">BASIC DRIVING</h2>
                              <h4><i class="fa fa-money" style="color:#bf3f22"></i> ৳ 7,000 BDT</i></h4>
                            
                                <h4><i class="fa fa-check" style="color:#03fc77"></i>Course : 30 Days</i></h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i>Dueration : 30 Minute/Class</h4>
                                     <h4><i class="fa fa-check" style="color:#03fc77"></i>Practical : 20 Days</h4>
                                  <h4><i class="fa fa-check" style="color:#03fc77"></i>Theory : 10 Days</h4>
                                   <h4><i class="fa fa-check" style="color:#03fc77"></i> 1st Installment : 4,000 BDT</h4>
                                    <h4><i class="fa fa-check" style="color:#03fc77" ></i> 2nd Installment : 3,000 BDT After 7 Classes</h4>
                                      
                                    <button type="Apply Now"  class="button"><a href="<?php echo e(URL::to('/admission')); ?>">Apply Now</a></button>
                             </div>
                              <ul>
                               <li><a href="#"><i class="fa fa-download"></i></a></li>
                               <li><a href="#"><i class="fa fa-comments"></i></a></li>
                              </ul>
                              <ul class="star-list">
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                        <li><i class="fa fa-star checked"></i></li>
                                    </ul>
                            </div>
                        
                       </div>
                   </div>
                </div> 
                  </div>
                </div>
  </div>
 </div>
 </div>
</section>



                
    

<section id="toppers" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="col-sm-12">
      <div class="Categories_1 text-center clearfix">
         <h1>MEET OUR TRAINERS</h1>
   </div>
   <div class="col-sm-12 space_all">
    <div class="team_home">
     <div class="col-sm-3">
      <div class="team_homei text-center">
         <div class="grid clearfix">
          <figure class="effect-jazz">
            <a href="#"><img src="<?php echo e(asset('frontend/img/38.jpg')); ?>" class="iw mgt" height="270" alt="img25"></a>
          </figure>
      </div>
         <div class="team_homeii">
          <h3><a href="#">Dapibus Diam</a></h3>
         
         <ul class="social-network social-circle">
            <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
            <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
   
         </ul>
         </div>
      </div>
     </div>
     <div class="col-sm-3">
      <div class="team_homei text-center">
         <div class="grid clearfix">
          <figure class="effect-jazz">
            <a href="#"><img src="<?php echo e(asset('frontend/img/39.jpg')); ?>" class="iw mgt" height="270" alt="img25"></a>
          </figure>
      </div>
         <div class="team_homeii">
          <h3><a href="#">Nibh Elementum </a></h3>
          
         <ul class="social-network social-circle">
            <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
            <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
           
         </ul>
         </div>
      </div>
     </div>
     <div class="col-sm-3">
      <div class="team_homei text-center">
         <div class="grid clearfix">
          <figure class="effect-jazz">
            <a href="#"><img src="<?php echo e(asset('frontend/img/40.jpg')); ?>" class="iw mgt" height="270" alt="img25"></a>
          </figure>
      </div>
         <div class="team_homeii">
          <h3><a href="#">Sagittis Ipsum</a></h3>
        
         <ul class="social-network social-circle">
            <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
            <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
           
         </ul>
         </div>
      </div>
     </div>
     <div class="col-sm-3">
      <div class="team_homei text-center">
         <div class="grid clearfix">
          <figure class="effect-jazz">
            <a href="#"><img src="<?php echo e(asset('frontend/img/41.jpg')); ?>" class="iw mgt" height="270" alt="img25"></a>
          </figure>
      </div>
         <div class="team_homeii">
          <h3><a href="#">Augue Semper</a></h3>
         
         <ul class="social-network social-circle">
            <li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
            <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
           
         </ul>
         </div>
      </div>
     </div>
    </div>
   </div>
   <div class="col-sm-12">
    <div class="toppers_l text-center clearfix">
       <h4><a class="button_1" href="#">View All Trainers</a></h4>
    </div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Fariha 300\drivingzone\resources\views/pages/home_content.blade.php ENDPATH**/ ?>