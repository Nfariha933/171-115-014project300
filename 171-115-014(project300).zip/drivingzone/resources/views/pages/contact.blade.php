<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Driving Zone</title>
	<link href="{{asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet">
	<link href="{{asset('frontend/css/global.css')}}" rel="stylesheet">
	<link href="{{asset('frontend/css/contact.css')}}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('frontend/css/font-awesome.min.css')}}" />
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<script src="{{asset('frontend/js/jquery-2.1.1.min.js')}}"></script>
    <script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
  </head>
  
<body>
<section id="top">
 <div class="container">
  <div class="row">
   <div class="col-sm-12">
    <div class="col-sm-6 space_all">
     <div class="top_1 clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="top_1l clearfix">
		<ul>
		 <li><a href="#"><i class="fa fa-envelope"></i> drivingschool@gmail.com</a></li>
		 </ul>
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="top_1l clearfix">
		 <ul>
		 <li><a href="#"><i class="fa fa-phone"></i> 01740069653</a></li>
		 </ul>
		</div>
	   </div>
	 </div>	
	</div>
	<div class="col-sm-6 space_all">
     <div class="top_1 text-right clearfix">
	   <div class="col-sm-6 space_left">
	    <div class="top_1l clearfix">
		
		</div>
	   </div>
	   <div class="col-sm-6 space_left">
	    <div class="top_1r clearfix">
		 <ul class="social-network social-circle">
                       
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
		</div>
	   </div>
	 </div>	
	</div>
   </div>
  </div>
 </div>
</section>

<section id="header" class="cd-secondary-nav clearfix">
	<nav class="navbar">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                <a class="navbar-brand" href="{{URL::to('/')}}"><span class="brand_1">D</span>Driving Zone<span class="brand_2">DRIVING SCHOOL</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="tag_m active_tab" href="{{URL::to('/')}}">Home</a>
                </li>
                    
                <li>
                    <a class="tag_m" href="{{URL::to('/course')}}">Courses</a>
                </li>
                
                <li>
                    <a class="tag_m" href="{{URL::to('/blog')}}">Blog</a>
                </li>
                
                <li>
                    <a class="tag_m" href="{{URL::to('/detail')}}">Details</a>
                </li>
                <li>
                    <a class="tag_m" href="{{URL::to('/about')}}">About Us</a>
                </li>
                
                <li>
                    <a class="tag_m" href="{{URL::to('/contact')}}">Contact</a>
                </li>

			        <li>
                        <a class="tag_m tag_m2" href="{{URL::to('/admission')}}">Get Admission</a>
                    </li>
					
					<li class="dropdown">
					  <a class="tag_m" href="#" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-user"></i>Account<span class="caret"></span></a>
					  <ul class="dropdown-menu drop_1" role="menu">
						<li><a href="{{URL::to('/admin')}}">Admin Login</a></li>
						<li><a href="{{URL::to('/std_login')}}">Students Login</a></li>
					  </ul> 
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</section>
				
					
					



<section id="contact">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="contact_1 clearfix">
	 <div class="col-sm-7">
	  <div class="blog_detail_1l8 clearfix">
	   <div class="blog_detail_1l8i clearfix"> 
	     <h1 class="mgt">Please let me know if you Have any Questions?</h1>
	    <div class="col-sm-6 space_left">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-user"></i></label>
            <input class="form-control" placeholder="Full Name" type="text">
		  </div>
		</div>
		<div class="col-sm-6 space_right">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-envelope"></i></label>
            <input class="form-control" placeholder="Email Address" type="text">
		  </div>
		</div>
	   </div>
	   <div class="blog_detail_1l8i clearfix"> 
		<div class="col-sm-12 space_all">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-pencil"></i></label>
            <input class="form-control" placeholder="Subject" type="text">
		  </div>
		</div>
		<div class="col-sm-12 space_all">
		  <div class="blog_detail_1l8i1 clearfix">
		    <label><i class="fa fa-pencil"></i></label>
            <textarea class="form-control form_1" placeholder="Review"></textarea>
		  </div>
		</div>
		<div class="col-sm-12 space_all">
		   <h4><a class="button_1" href="#">SEND MESSAGE</a></h4>
		 </div>
		</div>
	   </div>
	 </div>
	 <div class="col-sm-5">
	  <div class="contact_1r clearfix">
	    <div class="grid clearfix">
		  <figure class="effect-jazz">
			<a href="#"><img src="{{asset('frontend/img/66.jpg')}}" class="iw mgt" alt="img25"></a>
		  </figure>
	  </div>
	  </div>
	 </div>
	</div>
	
	  

   <div class="contact_3 col-sm-12 clearfix">
   	<h1>Our Location In Map</h1>
	  <iframe src="https://www.google.com/maps/d/embed?mid=1YjKSt3o3n_iXZwqGSPA_eVv1wI0&ie=UTF8&hl=en&msa=0&ll=24.51713900000002%2C89.32159400000002&spn=0.829643%2C2.139587&z=9&output=embed" style="width:100%; height:400px; border:0" allowfullscreen="">
	   </iframe>
	</div>
  </div>
 </div>
</section>
<section id="footer">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="footer_1 clearfix">
	 <div class="col-sm-3">
	  <div class="footer_1i clearfix">
	  	      <a class="navbar-brand" href="index.html"><span class="brand_1">D</span>riving Zone<span class="brand_2">DRIVING SCHOOL</span></a>
	   <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor.</p>
	   <ul>
	    <li><i class="fa fa-map-marker"></i> 21-23C Uvw Class Tu, Ad Nostra FA,</li>
		<li><i class="fa fa-envelope"></i> info@gmail.com</li>
		<li><i class="fa fa-phone"></i> +00 123 456 789</li>
	   </ul>
	  </div>
	 </div>
	 <div class="col-sm-3">
	   <div class="footer_1i1 clearfix">
	    <h3 class="mgt">Get in Touch</h3>
		<hr>
		<ul>
		 <li><a href="#"><i class="fa fa-facebook icon_1"></i> <span class="fb">Facebook</span></a></li>
		 <li><a href="#"><i class="fa fa-twitter icon_2"></i> <span class="tw">Twitter</span></a></li>
		 <li><a href="#"><i class="fa fa-google-plus icon_3"></i> <span class="gl">Google+</span></a></li>
		 <li><a href="#"><i class="fa fa-linkedin icon_4"></i> <span class="ld">Linkedin</span></a></li>
		</ul>
			<div class="input-group">
				<input type="text" class="form-control" placeholder="Subscribe Email">
				<span class="input-group-btn">
					<button class="btn btn-success" type="button">
						<i class="fa fa-envelope"></i></button>
				</span>
			</div>
	  </div>
	 </div>
	 <div class="col-sm-3">
	   <div class="footer_1i1 clearfix">
	    <h3 class="mgt">Gallery Images</h3>
		<hr>
		<div class="carousel slide" id="myCarousel">
                                    <!-- Carousel items -->
                                    <div class="carousel-inner">
                                        <div class="item" data-slide-number="0">
                                         <img src="{{asset('frontend/img/44.jpg')}}" alt="abc" class="iw mgt">
										</div>

                                        <div class="item active" data-slide-number="1">
                                         <img src="{{asset('frontend/img/45.jpg')}}" alt="abc" class="iw mgt">
										</div>

                                        <div class="item" data-slide-number="2">
                                         <img src="{{asset('frontend/img/46.jpg')}}" alt="abc" class="iw mgt">
										</div>

                                    </div><!-- Carousel nav -->
                                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                        <span class="glyphicon glyphicon-chevron-left"></span>                                       
                                    </a>
                                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                                        <span class="glyphicon glyphicon-chevron-right"></span>                                       
                                    </a>                                
                                    </div>
	  </div>
	 </div>
	 <div class="col-sm-3">
	   <div class="footer_1i2 clearfix">
	    <h3 class="mgt">Recent News</h3>
		<hr>
		<p><a href="#">New Your Focus to Prevent Overanalysis</a></p>
		<h5 class="mgt"><a href="#"><i class="fa fa-clock-o"></i> May 28,2019</a></h5>
		<p><a href="#">Three Social Media Hacks for the Busy Entrepreneur</a></p>
		<h5 class="mgt"><a href="#"><i class="fa fa-clock-o"></i> May 28,2019</a></h5>
	  </div>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>



<script>
	$(document).ready(function() {              
    $('i.glyphicon-thumbs-up, i.glyphicon-thumbs-down').click(function(){    
        var $this = $(this),
        c = $this.data('count');    
        if (!c) c = 0;
        c++;
        $this.data('count',c);
        $('#'+this.id+'-bs3').html(c);
    });      
    $(document).delegate('*[data-toggle="lightbox"]', 'click', function(event) {
        event.preventDefault();
        $(this).ekkoLightbox();
    });                                        
}); 

	</script>

<script>
$(document).ready(function(){

/*****Fixed Menu******/
var secondaryNav = $('.cd-secondary-nav'),
   secondaryNavTopPosition = secondaryNav.offset().top;
	$(window).on('scroll', function(){
		if($(window).scrollTop() > secondaryNavTopPosition ) {
			secondaryNav.addClass('is-fixed');	
		} else {
			secondaryNav.removeClass('is-fixed');
		}
	});	
	
});
</script>
</body>
 
</html>
