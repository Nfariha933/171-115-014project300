<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Driving Zone</title>
    <link href="{{asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('frontend/css/global.css')}}" rel="stylesheet">
    <link href="{{asset('frontend/css/index.css')}}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('frontend/css/font-awesome.min.css')}}" />
    <link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
    <script src="{{asset('frontend/js/jquery-2.1.1.min.js')}}"></script>
    <script src="{{asset('frontend/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('frontend/js/ekko-lightbox.js')}}"></script>
  </head>
  
<body>
<section id="top">
 <div class="container">
  <div class="row">
   <div class="col-sm-12">
    <div class="col-sm-6 space_all">
     <div class="top_1 clearfix">
       <div class="col-sm-6 space_left">
        <div class="top_1l clearfix">
         <ul>
          <li><a href="#"><i class="fa fa-envelope"></i> drivingschool@gmail.com</a></li>
         </ul>
        </div>
       </div>
       <div class="col-sm-6 space_left">
        <div class="top_1l clearfix">
         <ul>
          <li><a href="#"><i class="fa fa-phone"></i> 01740069653</a></li>
         </ul>
        </div>
       </div>
     </div> 
    </div>
    <div class="col-sm-6 space_all">
     <div class="top_1 text-right clearfix">
    
       <div class="col-sm-6 space_left">
        <div class="top_1r clearfix">
         <ul class="social-network social-circle">
                     
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
        </div>
       </div>
     </div> 
    </div>
   </div>
  </div>
 </div>
</section>

<section id="header" class="cd-secondary-nav clearfix">
    <nav class="navbar">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="{{URL::to('/')}}"><span class="brand_1">D</span>riving Zone<span class="brand_2">DRIVING SCHOOL</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="tag_m active_tab" href="{{URL::to('/')}}">Home</a>
                </li>
                    
                <li>
                    <a class="tag_m" href="{{URL::to('/course')}}">Courses</a>
                </li>
                
                <li>
                    <a class="tag_m" href="{{URL::to('/blog')}}">Blog</a>
                </li>
                
                <li>
                    <a class="tag_m" href="{{URL::to('/detail')}}">Details</a>
                </li>
                <li>
                    <a class="tag_m" href="{{URL::to('/about')}}">About Us</a>
                </li>
                
                <li>
                    <a class="tag_m" href="{{URL::to('/contact')}}">Contact</a>
                </li>

                <li>
                    <a class="tag_m tag_m2" href="{{URL::to('/admission')}}">Get Admission</a>
                </li>
                
                <li class="dropdown">
                    <a class="tag_m" href="#" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-user"></i>Account<span class="caret"></span></a>
                    <ul class="dropdown-menu drop_1" role="menu">
                    <li><a href="{{URL::to('/admin')}}">Admin Login</a></li>
                    <li><a href="{{URL::to('/std_login')}}">Students Login</a></li>
                    </ul> 
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</section>

<section id="center" class="center_home clearfix">
 <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
  <!-- Overlay -->
  <div class="overlay"></div>

  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#bs-carousel" data-slide-to="0" class=""></li>
    <li data-target="#bs-carousel" data-slide-to="1" class=""></li>
    <li data-target="#bs-carousel" data-slide-to="2" class="active"></li>
  </ol>
  
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item slides">
      <div class="slide-1"></div>
      <div class="hero">
            <p>Get start your journey</p>
            <h1>Welcome To Driving School <span></span></h1>        
            
      </div>
    </div>
    <div class="item slides">
      <div class="slide-2"></div>
      <div class="hero">        
            
      </div>
    </div>
    <div class="item slides active">
      <div class="slide-3"></div>
      <div class="hero">        
          <p>Get start your journey</p>
            <h1>Welcome To Driving School <span></span></h1>        
            
      </div>
    </div>
  </div> 
</div>
</section>

  @yield('content')
  
  </div>
 </div>
</section>




<section id="footer">
 <div class="container">
  <div class="row">
   <div class="col-sm-12 space_all">
    <div class="footer_1 clearfix">
     <div class="col-sm-3">
      <div class="footer_1i clearfix">
              <a class="navbar-brand" href="index.html"><span class="brand_1">D</span>riving Zone<span class="brand_2">DRIVING SCHOOL</span></a>
       <p>Pellentesque ultrices orci id justo vehicula, non aliquam erat lacinia. Mauris rhoncus venenatis tempor.</p>
       <ul>
        <li><i class="fa fa-map-marker"></i> 21-23C Uvw Class Tu, Ad Nostra FA,</li>
        <li><i class="fa fa-envelope"></i> info@gmail.com</li>
        <li><i class="fa fa-phone"></i> +00 123 456 789</li>
       </ul>
      </div>
     </div>
     <div class="col-sm-3">
       <div class="footer_1i1 clearfix">
        <h3 class="mgt">Get in Touch</h3>
        <hr>
        <ul>
         <li><a href="#"><i class="fa fa-facebook icon_1"></i> <span class="fb">Facebook</span></a></li>
         <li><a href="#"><i class="fa fa-twitter icon_2"></i> <span class="tw">Twitter</span></a></li>
         <li><a href="#"><i class="fa fa-google-plus icon_3"></i> <span class="gl">Google+</span></a></li>
         <li><a href="#"><i class="fa fa-linkedin icon_4"></i> <span class="ld">Linkedin</span></a></li>
        </ul>
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Subscribe Email">
                <span class="input-group-btn">
                    <button class="btn btn-success" type="button">
                        <i class="fa fa-envelope"></i></button>
                </span>
            </div>
      </div>
     </div>
     <div class="col-sm-3">
       <div class="footer_1i1 clearfix">
        <h3 class="mgt">Gallery Images</h3>
        <hr>
        <div class="carousel slide" id="myCarousel">
        <!-- Carousel items -->
        <div class="carousel-inner">
            <div class="item" data-slide-number="0">
                <img src="{{asset('frontend/img/44.jpg')}}" alt="abc" class="iw mgt">
            </div>

            <div class="item active" data-slide-number="1">
                <img src="{{asset('frontend/img/45.jpg')}}" alt="abc" class="iw mgt">
            </div>

            <div class="item" data-slide-number="2">
                <img src="{{asset('frontend/img/46.jpg')}}" alt="abc" class="iw mgt">
            </div>

        </div><!-- Carousel nav -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>                                       
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>                                       
        </a>                                
        </div>
      </div>
     </div>
     <div class="col-sm-3">
       <div class="footer_1i2 clearfix">
        <h3 class="mgt">Recent News</h3>
        <hr>
        <p><a href="#">New Your Focus to Prevent Overanalysis</a></p>
        <h5 class="mgt"><a href="#"><i class="fa fa-clock-o"></i> May 28,2019</a></h5>
        <p><a href="#">Three Social Media Hacks for the Busy Entrepreneur</a></p>
        <h5 class="mgt"><a href="#"><i class="fa fa-clock-o"></i> May 28,2019</a></h5>
      </div>
     </div>
    </div>
   </div>
  </div>
 </div>
</section>



<script>
    $(document).ready(function() {              
    $('i.glyphicon-thumbs-up, i.glyphicon-thumbs-down').click(function(){    
        var $this = $(this),
        c = $this.data('count');    
        if (!c) c = 0;
        c++;
        $this.data('count',c);
        $('#'+this.id+'-bs3').html(c);
    });      
    $(document).delegate('*[data-toggle="lightbox"]', 'click', function(event) {
        event.preventDefault();
        $(this).ekkoLightbox();
    });                                        
}); 

    </script>

<script>
$(document).ready(function(){

/*****Fixed Menu******/
var secondaryNav = $('.cd-secondary-nav'),
   secondaryNavTopPosition = secondaryNav.offset().top;
    $(window).on('scroll', function(){
        if($(window).scrollTop() > secondaryNavTopPosition ) {
            secondaryNav.addClass('is-fixed');  
        } else {
            secondaryNav.removeClass('is-fixed');
        }
    }); 
    
});
</script>

</body>
 
</html>
