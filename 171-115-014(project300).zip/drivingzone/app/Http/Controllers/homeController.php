<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;
session_start();

class homeController extends Controller
{
    public function index()
    {
        return view('pages.home_content');
    }

    public function course()
    {
        return view('pages.course');
    }
    public function blog()
    {
        return view('pages.blog');
    }
    public function detail()
    {
        return view('pages.detail');
    }
    public function about()
    {
        return view('pages.about');
    }
    public function contact()
    {
        return view('pages.contact');
    }
    public function admission()
    {
        return view('pages.admission');
    }
    public function std_login()
    {
        return view('admin.std');
    }



   


 
  
}
