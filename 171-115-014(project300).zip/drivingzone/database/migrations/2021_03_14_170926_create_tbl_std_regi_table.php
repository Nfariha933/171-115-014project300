<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTblStdRegiTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_std_regi', function (Blueprint $table) {
            $table->increments('student_id');
            $table->string('student_F_name');
            $table->string('student_L_name');
            $table->string('student_email');
            $table->string('student_password');
            $table->string('student_phone');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_std_regi');
    }
}
