<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\SliderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//-------------------------frontend--------------------------------


Route::get('/',[HomeController::class, 'index']);



//-------------------------beckend--------------------------------

Route::get('/logout',[SuperAdminController::class, 'logout']);
Route::get('/admin',[AdminController::class, 'index']);
Route::get('/dashboard',[AdminController::class, 'show_dashboard']);
Route::post('/admin_dashboard',[AdminController::class, 'dashboard']);
Route::get('/course',[HomeController::class, 'course']);
Route::get('/blog',[HomeController::class, 'blog']);
Route::get('/detail',[HomeController::class, 'detail']);
Route::get('/about',[HomeController::class, 'about']);
Route::get('/contact',[HomeController::class, 'contact']);
Route::get('/admission',[HomeController::class, 'admission']);
Route::get('/std_login',[HomeController::class, 'std_login']);


//-----------------------slider rout------------------------------------


Route::get('/add-slider', [SliderController::class, 'index']);
Route::post('/save-slider', [SliderController::class, 'save_slider']);
Route::get('/all-slider', [SliderController::class, 'all_slider']);
Route::get('/unactive_slider/{slider_id}', [SliderController::class, 'unactive_slider']); 
Route::get('/active_slider/{slider_id}', [SliderController::class, 'active_slider']);
Route::get('/delete_slider/{slider_id}', [SliderController::class, 'delete_slider']);
